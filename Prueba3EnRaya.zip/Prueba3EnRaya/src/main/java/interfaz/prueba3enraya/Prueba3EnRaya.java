package interfaz.prueba3enraya;

public class Prueba3EnRaya {

    // Método principal
    public static void main(String[] args) {
        VTablero2 vTablero2 = new VTablero2();
    }
}
